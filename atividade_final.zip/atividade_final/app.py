import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="Curso Superior - Sudeste", page_icon="🎓", layout="wide")

ARQUIVO = "Tabela_3_Areas_gerais_de_formacao_na_graduacao.xlsx"
AREA_CTEM = "Ciência, Tecnologia, Engenharias e Matemática (Exatas)"
AREA_EDU = "Educação, Serviços pessoais, Saúde e Bem-estar"
AREA_OUTRAS = "Outras áreas"
UFS_PERSONA = ["Minas Gerais", "Espírito Santo", "São Paulo", "Paraná", "Mato Grosso do Sul"]
REGIOES = ["Brasil", "Norte", "Nordeste", "Sudeste", "Sul", "Centro-Oeste"]


@st.cache_data
def carregar_dados(origem=ARQUIVO):
    """Lê a tabela do IBGE (cabeçalho em 3 linhas) e devolve no formato longo."""
    bruto = pd.read_excel(origem, header=None, skiprows=3)
    bruto = bruto.iloc[:, :10]
    bruto.columns = [
        "Local",
        "Total_Total", "Total_Homens", "Total_Mulheres",
        "CTEM_Total", "CTEM_Homens", "CTEM_Mulheres",
        "EDU_Total", "EDU_Homens", "EDU_Mulheres",
    ]
    bruto = bruto[bruto["Total_Total"].apply(lambda v: isinstance(v, (int, float)))].dropna(subset=["Local"])
    bruto = bruto[~bruto["Local"].str.startswith("Fonte")]

    # "Outras áreas" = total - (CTEM + Educação/Saúde)
    for sexo in ["Total", "Homens", "Mulheres"]:
        bruto[f"OUT_{sexo}"] = bruto[f"Total_{sexo}"] - bruto[f"CTEM_{sexo}"] - bruto[f"EDU_{sexo}"]

    linhas = []
    for _, r in bruto.iterrows():
        for sexo in ["Homens", "Mulheres"]:
            for cod, nome in [("CTEM", AREA_CTEM), ("EDU", AREA_EDU), ("OUT", AREA_OUTRAS)]:
                linhas.append({"Local": r["Local"], "Sexo": sexo,
                               "Área": nome, "Concluintes": int(r[f"{cod}_{sexo}"])})
    return pd.DataFrame(linhas)


st.title("🎓 Ensino Superior: quem se forma e em quê?")
st.caption("Persona 2 · Governadores de MG, ES, SP, PR e MS · Fonte: IBGE - Censo Demográfico "
           "(Tabela 10063, pessoas com nível superior completo)")

# ---------------- Dados (com upload opcional) ----------------
with st.sidebar:
    st.header("Filtros")
    upload = st.file_uploader("Usar outra tabela (mesmo formato .xlsx)", type="xlsx")

try:
    df = carregar_dados(upload) if upload else carregar_dados()
except Exception as erro:
    st.error(f"Não consegui ler a tabela enviada: {erro}")
    st.stop()

locais = [l for l in df["Local"].unique() if l not in REGIOES]
padrao = [u for u in UFS_PERSONA if u in locais]

with st.sidebar:
    estados = st.multiselect("Estado (UF)", sorted(locais), default=padrao)
    areas = st.multiselect("Área do conhecimento",
                           [AREA_CTEM, AREA_EDU, AREA_OUTRAS],
                           default=[AREA_CTEM, AREA_EDU, AREA_OUTRAS])
    sexos = st.multiselect("Sexo", ["Homens", "Mulheres"], default=["Homens", "Mulheres"])
    st.info("A tabela do IBGE traz um único levantamento (Censo), por isso não há filtro de ano.")

if not estados or not areas or not sexos:
    st.warning("Selecione ao menos um estado, uma área e um sexo na barra lateral.")
    st.stop()

dff = df[df["Local"].isin(estados) & df["Área"].isin(areas) & df["Sexo"].isin(sexos)]

# ---------------- KPIs ----------------
total = dff["Concluintes"].sum()
mulheres = dff.loc[dff["Sexo"] == "Mulheres", "Concluintes"].sum()


def pct_mulheres(area):
    base = dff[dff["Área"] == area]
    t = base["Concluintes"].sum()
    return base.loc[base["Sexo"] == "Mulheres", "Concluintes"].sum() / t * 100 if t else float("nan")


k1, k2, k3, k4 = st.columns(4)
k1.metric("Pessoas com curso superior", f"{total:,.0f}".replace(",", "."))
k2.metric("% de mulheres (total)", f"{mulheres / total * 100:.1f}%" if total else "-")
k3.metric("% mulheres em Exatas (CTEM)", f"{pct_mulheres(AREA_CTEM):.1f}%")
k4.metric("% mulheres em Educação/Saúde", f"{pct_mulheres(AREA_EDU):.1f}%")

st.divider()

# ---------------- Gráfico principal: barras 100% empilhadas ----------------
CURTO = {AREA_CTEM: "Exatas (CTEM)", AREA_EDU: "Educação, Saúde e Serviços", AREA_OUTRAS: "Outras áreas"}
CORES = {"Homens": "#2E86AB", "Mulheres": "#E4572E"}


def com_percentual(base, grupo):
    base = base.groupby(grupo + ["Sexo"], as_index=False)["Concluintes"].sum()
    base["% do curso"] = base["Concluintes"] / base.groupby(grupo)["Concluintes"].transform("sum") * 100
    base["Área"] = base["Área"].map(CURTO)
    return base


def barras_100(base, **kw):
    fig = px.bar(base, y="Área", x="% do curso", color="Sexo", orientation="h",
                 text=base["% do curso"].map("{:.0f}%".format), color_discrete_map=CORES,
                 hover_data={"Concluintes": ":,.0f", "% do curso": ":.1f"}, **kw)
    fig.update_xaxes(range=[0, 100], ticksuffix="%", title_text="")
    fig.update_yaxes(title_text="", autorange="reversed")
    fig.update_traces(textposition="inside", textfont_color="white")
    fig.update_layout(barmode="stack", legend_title_text="", legend_orientation="h", legend_y=-0.15)
    return fig


st.subheader("Proporção de gênero por área de formação (barras 100% empilhadas)")
st.caption("Cada barra soma 100% das pessoas formadas naquela área, naquele estado.")
fig = barras_100(com_percentual(dff, ["Local", "Área"]), facet_col="Local", facet_col_wrap=3)
fig.for_each_annotation(lambda a: a.update(text=a.text.split("=")[-1]))
fig.update_layout(height=560)
st.plotly_chart(fig, width="stretch")

st.subheader("Total consolidado dos estados selecionados")
fig2 = barras_100(com_percentual(dff, ["Área"]))
fig2.update_layout(height=320)
st.plotly_chart(fig2, width="stretch")

# ---------------- Distribuição por estado ----------------
st.subheader("Como os concluintes se distribuem entre os estados")
dist = dff.groupby("Local", as_index=False)["Concluintes"].sum().sort_values("Concluintes")
fig3 = px.bar(dist, x="Concluintes", y="Local", orientation="h", text_auto=",.0f",
              color_discrete_sequence=["#6C5B7B"], labels={"Local": "", "Concluintes": "Concluintes"})
fig3.update_layout(height=350)
st.plotly_chart(fig3, width="stretch")

with st.expander("Ver dados filtrados"):
    st.dataframe(dff, width="stretch")

# ---------------- Notícias ----------------
st.divider()
st.subheader("📰 Para entender o contexto")
st.caption("Leituras sobre fuga de cérebros, escassez de profissionais de TI/Exatas e presença feminina em STEM.")
noticias = [
    ("🧠 Fuga de cérebros",
     "Apagão profissional: há vagas abertas, mas talentos estão fugindo do Brasil",
     "Tecnoblog",
     "https://tecnoblog.net/495835/apagao-profissional-ha-vagas-abertas-mas-talentos-estao-fugindo-do-brasil/"),
    ("💻 Escassez de TI/Exatas",
     "Sobram vagas, apesar de salário alto: o que explica escassez de profissionais de TI no Brasil?",
     "InfoMoney",
     "https://www.infomoney.com.br/?p=2260681"),
    ("👩‍🔬 Mulheres em STEM",
     "Quem são as mulheres na ciência e por que elas precisam estar cada vez mais presentes",
     "Portal da Indústria",
     "https://noticias.portaldaindustria.com.br/noticias/inovacao-e-tecnologia/quem-sao-as-mulheres-na-ciencia-e-por-que-elas-precisam-estar-cada-vez-mais-presentes/"),
]
cols = st.columns(3)
for col, (tema, titulo, fonte, link) in zip(cols, noticias):
    with col:
        with st.container(border=True):
            st.markdown(f"### {tema}")
            st.markdown(f"**{titulo}**")
            st.caption(fonte)
            st.link_button("Ler matéria", link)
